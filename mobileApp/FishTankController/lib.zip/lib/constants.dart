const String LOGINURL="http://35.173.230.92:33000/login";
const String SIGNUPURL='http://35.173.230.92:33000/signup';
const String GETTANKIDSURL='http://35.173.230.92:33000/app/getdevicedata';
const String ADDTANKURL='http://35.173.230.92:33000/app/addtank';
const String GETFISHNAMES='http://35.173.230.92:33000/app/fishnames';
const String FEEDNOW="http://35.173.230.92:33000/control/feed";
const String RENEW="http://35.173.230.92:33000/control/renew";
const String GRAPHURL="http://35.173.230.92:33000/app/retrivedata";
const String DELETETANKURL="http://35.173.230.92:33000/app/deletetank";

